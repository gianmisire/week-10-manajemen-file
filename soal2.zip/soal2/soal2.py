with open('soal.txt', 'r') as file:
    daftar_soal = file.readlines()

print("nama file: soal.txt\n")

for baris in daftar_soal:
    soal, jawaban = baris.split('||')
    soal = soal.strip()
    jawaban = jawaban.strip()

    print(soal)
    user_jawab = input("Jawab: ")

    if user_jawab.strip().lower() == jawaban.lower():
        print("Jawaban benar!\n")
    else:
        print("Jawaban salah!\n")
        