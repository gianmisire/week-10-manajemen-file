with open('file1.txt', 'r') as f1, open('file2.txt', 'r') as f2:
    baris1 = f1.readlines()
    baris2 = f2.readlines()

maks_baris = max(len(baris1), len(baris2))

print("Perbedaan antar file:\n")

for i in range(maks_baris):
    teks1 = baris1[i].strip() if i < len(baris1) else "<Tidak ada baris>"
    teks2 = baris2[i].strip() if i < len(baris2) else "<Tidak ada baris>"

    if teks1 != teks2:
        print(f"Baris ke-{i+1} berbeda:")
        print(f"File 1: {teks1}")
        print(f"File 2: {teks2}")
        print("-" * 40)
        